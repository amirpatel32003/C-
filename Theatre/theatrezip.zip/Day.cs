﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theatre
{
    public enum Day
    {
        Sun, Mon, Tue, Wed, Thu, Fri, Sat
    }

}
